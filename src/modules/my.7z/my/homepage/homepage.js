import { LightningElement, track } from 'lwc';

export default class Homepage extends LightningElement {
    @track value = 0;
    slides = [
        {
            id: 1,
            background:
                '../../../resources/assets/docAppointment/carousel1.jpg',
            title: '',
            subtitle1: '',
            subtitle2: ''
        },
        {
            id: 2,
            background:
                '../../../resources/assets/docAppointment/carousel3.jpg',
            title: '',
            subtitle1: '',
            subtitle2: ''
        },
        {
            id: 3,
            background:
                '../../../resources/assets/docAppointment/carousel10.jpg',
            title: '',
            subtitle1: '',
            subtitle2: ''
        }
    ];

    stateOptions = [{
        id: 0,
        value: 'Select State...',
        label: 'Select State...'
    },{
        id: 1,
        value: 'Karnataka',
        label: 'Karnataka'
    },
    {
        id: 2,
        value: 'Maharashtra',
        label: 'Maharashtra'
    },
    {
        id: 3,
        value: 'Tamil Nadu',
        label: 'Tamil Nadu'
    }
    ]

    @track cities = [
        {
            code: "Karnataka",
            value: 'Select City...',
            label: 'Select City...'
        },
        {
            code: "Karnataka",
            label: "Bangalore",
            value: "Bangalore"
        },
        {
            code: "Karnataka",
            label: "Mysore",
            value: "Mysore"
        },
        {
            code: "Karnataka",
            label: "Hubli",
            value: "Hubli"
        }, {
            code: "Maharashtra",
            label: "Mumbai",
            value: "Mumbai"
        },
        {
            code: "Maharashtra",
            label: "Pune",
            value: "Pune"
        },
        {
            code: "Maharashtra",
            label: "Nagpur",
            value: "Nagpur"
        }, {
            code: "Tamil Nadu",
            label: "Chennai",
            value: "Chennai"
        },
        {
            code: "Tamil Nadu",
            label: "Coimbatore",
            value: "Coimbatore"
        },
        {
            code: "Tamil Nadu",
            label: "Madurai",
            value: "Madurai"
        }];

    Value(){
        this.value += 1;
    }

    bindCities(currentState) {
        var cityList = [];
        this.cities.forEach(function (item) {
            if (currentState.toUpperCase() === (item.code.toUpperCase())) {
                cityList.push(item);
            }
        });
        return cityList
    }

}
