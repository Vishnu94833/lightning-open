import { LightningElement } from 'lwc';

export default class DoctorAppointment extends LightningElement {}
