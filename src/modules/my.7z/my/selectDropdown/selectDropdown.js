import { LightningElement, api, track } from 'lwc';

export default class SelectDropdown extends LightningElement {
    @api label;
    @api options;
    options = [{
        id: 1,
        value: 'Option1',
        label: 'Option1'
    },
    {
        id: 2,
        value: 'Option2',
        label: 'Option2'
    },
    {
        id: 3,
        value: 'Option3',
        label: 'Option3'
    },
    {
        id: 4,
        value: 'Option4',
        label: 'Option4'
    }
    ]
    @track value='';  

    selectedValue(event){
        this.value = event;
        console.log(this.value);
        
    }
}
